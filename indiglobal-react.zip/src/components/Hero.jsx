function Hero() {
  return (
    <section className="hero">
      <div className="container">
        <div className="hero-content">
          <h1>Authentic Indian Products Delivered Worldwide</h1>
          <p>Bringing the taste and essence of India to your doorstep, no matter where you are in the world.</p>
          <a href="#" className="btn">Shop Now</a>
          <a href="#" className="btn btn-secondary">Learn More</a>
        </div>
      </div>
    </section>
  );
}
export default Hero;