function Header() {
  return (
    <header>
      <div className="container header-top">
        <div className="logo">
          <i className="fas fa-globe-asia"></i>
          <span>IndiGlobal</span>
        </div>
        <div className="country-selector">
          <span>Ship to:</span>
          <select id="country-select">
            <option value="US">United States</option>
            <option value="CA">Canada</option>
            <option value="UK">United Kingdom</option>
            <option value="AU">Australia</option>
            <option value="DE">Germany</option>
            <option value="FR">France</option>
            <option value="AE">UAE</option>
            <option value="ZA">South Africa</option>
          </select>
        </div>
        <div className="user-actions">
          <a href="#"><i className="fas fa-user"></i> Sign In</a>
          <a href="#" className="cart-icon">
            <i className="fas fa-shopping-cart"></i>
            <span className="cart-count">0</span>
          </a>
        </div>
      </div>
    </header>
  );
}
export default Header;